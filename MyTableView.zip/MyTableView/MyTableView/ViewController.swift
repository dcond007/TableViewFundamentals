//
//  ViewController.swift
//  MyTableView
//
//  Created by Astronaut Elvis on 1/28/22.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var myTableView: UITableView!
    @IBOutlet weak var myTextField: UITextField!
    
    
    var myArray = ["this is my first item", "this is my second", "third here", "also a fourth"]
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return myArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let myCell = myTableView.dequeueReusableCell(withIdentifier: "TableViewCell") as! TableViewCell
        myCell.myLabel.text = myArray[indexPath.row]
        return myCell
    }
    

    override func viewDidLoad() {
        super.viewDidLoad()
        myTableView.dataSource = self
        myTableView.delegate = self
        // Do any additional setup after loading the view.
    }

    @IBAction func onPostClick(_ sender: Any) {
        
        if (!(myTextField.text!.isEmpty)) {
            myArray.append(myTextField.text!)
            myTableView.reloadData()
        }
    }
    
}

